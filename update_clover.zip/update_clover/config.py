import os
import time

# Colors for visual feedback
RED = "\033[0;31m"
GREEN = "\033[0;32m"
YELLOW = "\033[0;33m"
NC = "\033[0;m" # No color

# Absolute path to the script directory
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# Log file with timestamp
LOGFILE = os.path.join(SCRIPT_DIR, f"update_clover_{time.strftime('%Y%m%d%H%M%S')}.log")

# Base directory for EFI backups
BACKUP_BASE_DIR = os.path.expanduser("~")

# --- Clover Settings ---
# Base URL of the Clover repository (GitHub API)
CLOVER_REPO_URL = "https://api.github.com/repos/YBronst/CloverBootloader/releases/latest"

# Direct download URL (if you want to force a specific version, uncomment below and comment out CLOVER_REPO_URL)
# CLOVER_DOWNLOAD_URL = "https://github.com/YBronst/CloverBootloader/releases/download/5163/CloverV2-5163.zip"

# Minimum acceptable size for the Clover.zip file (in bytes)
MIN_CLOVER_ZIP_SIZE = 1000000 # 1 MB

# Expected SHA256 hash for the Clover.zip file (for integrity verification)
# You will need to calculate the hash of the downloaded file and place it here.

# Example: CLOVER_SHA256 = "sha256:2809a7dd9afea07986ff8ebaa26e8a3bb3ec9d77094483420d17acd5cd562c0a" # (SHA256 hash of an empty file)
CLOVER_SHA256 = "" # Leave blank if you don't want to verify integrity