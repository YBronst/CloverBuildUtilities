#!/usr/bin/env python3
from efi_handler import EFI_DIR, is_efi_read_only
from logger import logger, YELLOW, RED, GREEN
from clover_updater import (
    update_bootx64,
    update_cloverx64,
    update_clover_drivers,
)
import sys

def show_menu(efi_dir, clover_zip_path):
    """Display the main menu and get the user's choice."""
    while True:
        # Show the menu with translated messages
        print("\n=== " + logger("clover_update_menu", YELLOW, return_message=True) + " ===")
        print("1. " + logger("Update BOOTX64.efi and CLOVERX64.efi", YELLOW, return_message=True))
        print("2. " + logger("Update Drivers", YELLOW, return_message=True))
        print("3. " + logger("Full Update", YELLOW, return_message=True))
        print("4. " + logger("option exit", YELLOW, return_message=True))

        choice = input("\n" + logger("choose_option", YELLOW, return_message=True) + " ")

        # Check if the EFI partition is mounted and writable before proceeding
        if not is_efi_read_only(efi_dir):
            logger("efi_ready", GREEN, efi_dir=efi_dir)
        else:
            logger("efi_not_writable", RED, efi_dir=efi_dir)
            continue

        if choice == "1":
            update_boot_and_clover(efi_dir, clover_zip_path)
        elif choice == "2":
            update_drivers(efi_dir, clover_zip_path)
        elif choice == "3":
            update_all(efi_dir, clover_zip_path)
        elif choice == "4":
            logger("exiting", YELLOW)
            sys.exit(0)
        else:
            logger("invalid_option", RED)

def update_bootx64_only(efi_dir, clover_zip_path):
    """Update BOOTX64.efi file in the EFI partition."""
    logger("start_update_bootx64", YELLOW)
    try:
        update_bootx64(efi_dir, clover_zip_path)
        logger("success_update_bootx64", GREEN)
    except Exception as e:
        logger("error_updating_bootx64", RED, error=e)

def update_cloverx64_only(efi_dir, clover_zip_path):
    """Update CLOVERX64.efi file in the EFI partition."""
    logger("start_update_cloverx64", YELLOW)
    try:
        update_cloverx64(efi_dir, clover_zip_path)
        logger("success_update_cloverx64", GREEN)
    except Exception as e:
        logger("error_updating_cloverx64", RED, error=e)

def update_drivers(efi_dir, clover_zip_path):
    """Update UEFI drivers in the EFI partition."""
    logger("start_update_drivers", YELLOW)
    try:
        update_clover_drivers(efi_dir, clover_zip_path)
        logger("uefi_drivers_update_success", GREEN)
    except Exception as e:
        logger("error_updating_drivers", RED, error=e)

def update_all(efi_dir, clover_zip_path):
    """Update all Clover components (BOOTX64.efi, CLOVERX64.efi and drivers)."""
    logger("start_full_update", YELLOW)
    try:
        update_boot_and_clover(efi_dir, clover_zip_path)
        update_drivers(efi_dir, clover_zip_path)
        logger("full_update_success", GREEN)
    except Exception as e:
        logger("error_updating_clover", RED, error=e)

def update_boot_and_clover(efi_dir, clover_zip_path):
    """Update BOOTX64.efi and CLOVERX64.efi files in the EFI partition."""
    logger("start_update_boot_clover", YELLOW)
    try:
        update_bootx64(efi_dir, clover_zip_path)
        update_cloverx64(efi_dir, clover_zip_path)
        logger("boot_clover_update_success", GREEN)
    except Exception as e:
        logger("boot_clover_update_error", RED, error=e)
